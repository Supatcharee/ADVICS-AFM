CREATE TABLE [dbo].[tbt_transaction_log](
	[TransactionID] [int] IDENTITY(1,1) NOT NULL,
	[User] [nvarchar](50) NULL,
	[Text] [nvarchar](4000) NULL,
	[GetDate] [nvarchar](50) NULL,
	[StoreName] [nvarchar](100) NULL,
	[StartTime] [time](7) NULL,
	[EndTime] [time](7) NULL
) ON [PRIMARY]
GO
CREATE PROCEDURE [dbo].[sp_system_GetTransactionLog] 
	  @UserID NVARCHAR(15)
	, @Text NVARCHAR(3000)
	, @StoreName NVARCHAR(150)
AS
BEGIN
	IF EXISTS (
			SELECT 1
			FROM tbt_Transaction_log
			WHERE [Text] = @Text
				AND [storeName] = @StoreName
				AND [EndTime] IS NULL
			)
	BEGIN
		UPDATE tbt_Transaction_log
		SET [endtime] = cast(getdate() AS TIME)
		WHERE [Text] = @Text
			AND [storeName] = @StoreName
			AND [EndTime] IS NULL
	END
	ELSE
	BEGIN
		PRINT 'in'

		INSERT INTO tbt_Transaction_log (
			[User]
			, [Text]
			, [GetDate]
			, [StoreName]
			, [StartTime]
			)
		VALUES (
			@UserID
			, @Text
			, GETDATE()
			, @StoreName
			, CAST(GETDATE() AS TIME)
			)
	END
END
GO
ALTER PROCEDURE [dbo].[sp_XMSS050_Product_LoadImage]
(
	@ProductID   INT
)
AS
BEGIN
	
	
	--Start Add Log
	DECLARE @Text VARCHAR(100) = 'Start Call with @ProductID:' + CAST(@ProductID AS VARCHAR(50));	
	EXEC sp_system_GetTransactionLog
		'System',
		@Text ,
		'sp_XMSS050_Product_LoadImage'
	--End Add Log
	
	
		SELECT ImageFile
        FROM tbm_ProductImage P 
		WHERE P.ProductID = @ProductID


	--Start Add Log
	SET @Text = 'End Call with @ProductID:' + CAST(@ProductID AS VARCHAR(50));
	EXEC sp_system_GetTransactionLog
		'System',
		@Text,
		'sp_XMSS050_Product_LoadImage'
	--End Add Log
	
END
GO
ALTER PROCEDURE [dbo].[sp_XMSS050_Product_LoadQCImage]
(
	@ProductCode   NVARCHAR(50) 
)
AS
BEGIN

	--Start Add Log
	DECLARE @Text VARCHAR(100) = 'Start Call with @ProductCode:' + @ProductCode;	
	EXEC sp_system_GetTransactionLog
		'System',
		@Text ,
		'sp_XMSS050_Product_LoadQCImage'
	--End Add Log

	SELECT QCPicture
    FROM tbm_ProductImage PDI INNER JOIN tbm_Product PD ON PDI.ProductID = PD.ProductID
	WHERE PDI.ProductCode = @ProductCode AND PD.DeleteFlag = 0

	--Start Add Log
	SET @Text = 'End Call with @ProductCode:' + @ProductCode;	
	EXEC sp_system_GetTransactionLog
		'System',
		@Text,
		'sp_XMSS050_Product_LoadQCImage'
	--End Add Log

END